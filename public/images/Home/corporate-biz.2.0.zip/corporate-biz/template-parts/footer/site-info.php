<?php
/**
 * The template used for displaying credits
 *
 * @package Corporate_Biz
 */
?>

<?php
/**
 * corporate_biz_credits hook
 * @hooked corporate_biz_footer_content - 10
 */
do_action( 'corporate_biz_credits' );
